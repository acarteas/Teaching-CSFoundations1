# CS 111 Lab 10
Agenda:
* Write basic code cracker
* Develop "random" Caesar cipher
* Count number of words in a file
* Count number of characters in a file
* Count number of sentences in a file
